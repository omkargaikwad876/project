# CodeSentry — AI-Powered Security Code Reviewer

CodeSentry takes a natural-language question and a code snippet, and answers like an application security expert. It uses Gemini with a security-expert system prompt and a local `scan_vulnerabilities` tool. **The model decides** whether to call the tool; the Google Gen AI SDK's automatic function calling runs it, feeds the result back, and the model writes the final structured review.

```
user query + snippet ──► Gemini (system prompt: security expert)
                              │  risky code? ──► scan_vulnerabilities(code, language)  [local, pure Python]
                              │                         │
                              ◄──────── findings JSON ──┘   (SDK automatic function calling)
                              ▼
            Verdict · Findings (severity + fix) · Explanation · Next steps
```

## Project structure

```
code_sentry/
├── main.py            # CLI + review() agent function
├── tools.py           # scan_vulnerabilities (pure, regex/heuristic)
├── prompts.py         # system prompt
├── demo.py            # runs all sample cases end to end
├── examples/          # sample snippets (vulnerable and clean)
├── tests/
│   ├── test_tools.py  # scanner unit tests (no LLM needed)
│   └── test_main.py   # agent error handling with a fake client
├── requirements.txt
└── pytest.ini
```

## Setup

Requires Python 3.10+.

```bash
cd code_sentry
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export GEMINI_API_KEY="your-key"     # Windows (PowerShell): $env:GEMINI_API_KEY="your-key"
```

Optional: `export GEMINI_MODEL=gemini-2.5-pro` to change the model (default `gemini-2.5-flash`).

## How to run

```bash
python main.py -q "Is this function safe to use in production?" -f examples/vulnerable_login.py
python main.py -q "Any risk here?" -c 'data = yaml.load(open("cfg.yml"))'
cat examples/server.js | python main.py -q "Review this route" -l javascript
python main.py                                   # interactive: type question, paste code, end with END
python main.py -v -q "Is this OK?" -f examples/clean_utils.py   # -v shows whether the tool was called
python main.py --scan-only -f examples/config_loader.py         # local scanner only, no API key needed
```

Run the demo (all sample cases, plus tool-trigger accuracy and the empty-snippet case):

```bash
python demo.py
```

Without `GEMINI_API_KEY`, `demo.py` falls back to printing the local scanner results.

Run the tests (no API key or network needed):

```bash
pytest
```

## What the scanner detects

| Rule  | Category                  | Examples of what is flagged                                              | Severity |
|-------|---------------------------|---------------------------------------------------------------------------|----------|
| CS001 | Hardcoded secret          | `API_KEY = "..."`, AWS/Google/GitHub/Slack/`sk-` keys, private key blocks, `user:pass@` URLs | high |
| CS002 | Dynamic code execution    | `eval()`, `exec()`, `new Function()`                                      | critical if user input reaches it, else high |
| CS003 | SQL injection             | SQL built with f-strings, `+`, `%`, `.format()`, JS template literals     | critical |
| CS004 | Command injection         | `shell=True`, `os.system`, `os.popen`, Node `child_process.exec`          | critical if user input, else high |
| CS005 | Insecure deserialization  | `pickle.loads`, `marshal`, `dill`, `yaml.load` without `SafeLoader`, `yaml.unsafe_load` | high |
| CS006 | Weak hashing              | `md5` / `sha1` (Python, JS, Java, PHP)                                    | high near password code, else low |
| CS007 | Missing input validation  | `request.*`, `req.*`, `input()`, `sys.argv` flowing into `open`, `send_file`, `redirect`, `requests.get`, etc. with no validation step | medium |
| CS008 | TLS verification disabled | `verify=False`, `rejectUnauthorized: false`                               | medium |
| CS009 | Debug mode enabled        | `app.run(debug=True)`, `DEBUG = True`                                     | medium |

Each finding returns `rule_id`, `category`, `severity`, `line`, `code`, `description` and `recommendation`. Findings are de-duplicated per rule and line and sorted by severity.

Things that are deliberately **not** flagged: parameterized queries (`execute("... ?", (x,))`), `subprocess.run([...])` without a shell, `yaml.safe_load`, `.execute()` method calls, secrets read from environment variables, placeholders like `"<your-key>"`, and anything in comment lines.

## Example

**Input**

```bash
python main.py -v -q "Is this safe to use in production?" -f examples/config_loader.py
```

```python
import yaml
from flask import request, send_file

def load_config(path):
    with open(path) as fh:
        return yaml.load(fh)

def download():
    name = request.args.get("file")
    return send_file(name)
```

**Tool result** (real output of `scan_vulnerabilities`, which the model receives)

```json
{
  "status": "ok",
  "language": "python",
  "lines_scanned": 10,
  "finding_count": 2,
  "highest_severity": "high",
  "findings": [
    {
      "rule_id": "CS005",
      "category": "Insecure deserialization",
      "severity": "high",
      "line": 6,
      "code": "return yaml.load(fh)",
      "description": "yaml.load without SafeLoader can create arbitrary Python objects from the input (code execution risk).",
      "recommendation": "Use yaml.safe_load(data) or yaml.load(data, Loader=yaml.SafeLoader)."
    },
    {
      "rule_id": "CS007",
      "category": "Missing input validation",
      "severity": "medium",
      "line": 10,
      "code": "return send_file(name)",
      "description": "'name' comes from user input (line 9) and reaches send_file() without validation (e.g. path traversal or open redirect).",
      "recommendation": "Validate before use: check type, length and format, and prefer an allow-list of accepted values."
    }
  ]
}
```

**Final response** (illustrative; exact wording varies per run)

```
[scan_vulnerabilities called: yes]

**Verdict:** High risk — not safe for production yet; two issues let an attacker run code or read arbitrary files.

**Findings:**
1. [HIGH] Insecure YAML loading — line 6
   yaml.load can create Python objects from the file, so a malicious config can run code.
   Fix: return yaml.safe_load(fh)
2. [MEDIUM] Unvalidated file download — line 10
   The filename comes straight from the URL, so ?file=../../etc/passwd can read any file the server can access.
   Fix: return send_from_directory(DOWNLOAD_DIR, secure_filename(name))

**Explanation:**
Both problems come from trusting input. YAML files and URL parameters can be written by an attacker. "Path traversal" means using ../ to escape the folder you meant to serve.

**Next steps:**
- Switch to yaml.safe_load everywhere.
- Serve downloads only from a fixed folder with secure_filename.
- Add a test that requests ../ paths and expects a 404.
```

**Clean snippet** (`examples/clean_utils.py`, pure math and string helpers): the model is instructed to skip the tool, and replies with `**Verdict:** Safe` and "No security issues found." `demo.py` prints whether the tool was called for every case and a final trigger-accuracy score.

**Scanner results for all samples** (`python demo.py` without an API key):

```
vulnerable_login.py    highest=critical ["L14 CRITICAL SQL injection", "L6 HIGH Hardcoded secret", "L7 HIGH Hardcoded secret", "L12 HIGH Weak password hashing", "L18 MEDIUM Debug mode enabled"]
deploy_helper.py       highest=critical ["L13 CRITICAL Dynamic code execution", "L6 HIGH Command injection", "L9 HIGH Insecure deserialization"]
config_loader.py       highest=high     ["L6 HIGH Insecure deserialization", "L10 MEDIUM Missing input validation"]
server.js              highest=critical ["L6 CRITICAL SQL injection", "L10 CRITICAL Command injection", "L2 HIGH Hardcoded secret"]
clean_utils.py         highest=none     []
safe_query.py          highest=none     []
```

## Design decisions

- **Model-driven tool use.** `scan_vulnerabilities` is passed as a Python function in `tools=[...]`. The SDK builds the tool schema from its type hints and docstring (the docstring is the tool description the model sees) and runs the call loop automatically, capped at 3 calls. `main.py` contains no "if risky then scan" logic; it only reads `automatic_function_calling_history` to report whether the tool was used.
- **Scanner findings are leads, not truth.** The prompt tells the model to confirm each finding, drop false positives, add issues it spots manually, and never invent findings.
- **Prompt-injection guard.** The snippet is wrapped in `<code>` tags and the prompt tells the model to ignore instructions inside it.
- **Pure tool.** `scan_vulnerabilities` has no I/O or global state, returns plain dicts, and never raises (internal errors come back as `{"status": "error", ...}` so the model can fall back to a manual review).
- **Errors never crash the app.** Empty snippet, missing key, oversized input, API errors (quota, auth, network), and empty or blocked responses all return a clear message and exit code 1.

## Assumptions and limitations

- Detection is regex and heuristic based, line by line. It can miss issues split across many lines or hidden behind helper functions, and it can occasionally flag harmless code (e.g. an English sentence like "select an item from the list" concatenated with a variable). The LLM review step exists partly to filter these.
- Taint tracking for input validation is simple: a variable assigned from a user-input source, used in a sensitive call, with no validation step in between. It does not follow data across functions or files.
- "Validation" is recognized by common patterns (`isinstance`, `re.fullmatch`, `secure_filename`, allow-list checks, `.isdigit()`, pydantic models, etc.).
- MD5/SHA-1 are high severity only when password-related names appear within 3 lines; otherwise low (checksums are a legitimate use).
- Language support is best for Python, with the main patterns also covering JavaScript/Node, Java and PHP. The language hint is optional; `auto` guesses from the code.
- Snippet size is capped at 200,000 characters.
- Whether the tool is called is the model's decision, so it can vary slightly between runs and models. Use `-v` or `demo.py` to check.
- All keys and passwords in `examples/` are fake.
- Bandit integration (stretch goal) is not included.
