import json
import os
import sys
from pathlib import Path

from main import review
from tools import scan_vulnerabilities

EXAMPLES = Path(__file__).resolve().parent / "examples"

CASES = [
    ("Is this login function safe to use in production?", "vulnerable_login.py", "python", True),
    ("Our DevOps helper script. Anything dangerous here?", "deploy_helper.py", "python", True),
    ("Can you check this config loader and download endpoint?", "config_loader.py", "python", True),
    ("Quick review of this Express route before I ship it?", "server.js", "javascript", True),
    ("Is this utility module OK?", "clean_utils.py", "python", False),
    ("Is this database access code secure?", "safe_query.py", "python", True),
]


def run_live():
    hits = 0
    for i, (query, filename, language, expect_tool) in enumerate(CASES, start=1):
        code = (EXAMPLES / filename).read_text()
        print(f"\n{'=' * 78}\n[{i}] {filename}\nQuery: {query}\n{'-' * 78}")
        result = review(query, code, language)
        if not result.ok:
            print(f"Error: {result.error}")
            continue
        match = result.tool_called == expect_tool
        hits += match
        print(f"scan_vulnerabilities called: {'yes' if result.tool_called else 'no'} "
              f"(expected {'yes' if expect_tool else 'no'}) {'OK' if match else 'MISMATCH'}\n")
        print(result.text)
    print(f"\n{'=' * 78}\nTool-trigger accuracy: {hits}/{len(CASES)}")
    print(f"\n{'=' * 78}\n[edge] Empty snippet\n{review('Is this safe?', '').error}")


def run_offline():
    print("GEMINI_API_KEY not set: showing local scanner output only.\n")
    for _, filename, language, _ in CASES:
        result = scan_vulnerabilities((EXAMPLES / filename).read_text(), language)
        summary = [f"L{f['line']} {f['severity'].upper()} {f['category']}" for f in result["findings"]]
        print(f"{filename:22} highest={result['highest_severity']:8} {json.dumps(summary)}")


if __name__ == "__main__":
    run_live() if os.environ.get("GEMINI_API_KEY") else run_offline()
    sys.exit(0)
