import re

SEVERITY_RANK = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
COMMENT_LINE = re.compile(r"^\s*(#(?!!)|//|/\*|\*(\s|/|$)|<!--|--(\s|$))")
MAX_CODE_CHARS = 200_000

SECRET_ASSIGN = re.compile(
    r"""(?i)\b[\w-]*(password|passwd|pwd|secret|api[_-]?key|access[_-]?key|auth[_-]?token|token|private[_-]?key|client[_-]?secret)[\w-]*["']?\s*[:=]\s*["']([^"'\s]{6,})["']"""
)
PLACEHOLDER = re.compile(r"(?i)^(<.*>|\$\{.*\}|\{\{.*\}\}|your[_-].*|x{4,}|\*{3,}|\.{3,}|example.*|placeholder|redacted|os\.environ.*)$")
KEY_PATTERNS = [
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS access key"),
    (re.compile(r"\bAIza[0-9A-Za-z_\-]{35}"), "Google API key"),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}"), "secret API key (sk-...)"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36}\b"), "GitHub token"),
    (re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}"), "Slack token"),
    (re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"), "private key"),
    (re.compile(r"\b[a-z][a-z0-9+]*://[^:\s/'\"]+:(?!\$\{)[^@\s/'\"]{3,}@"), "password in connection URL"),
]

TAINT_SOURCE = re.compile(
    r"\binput\s*\(|\brequest\.(args|form|values|json|data|files|cookies|headers|GET|POST|get_json)\b"
    r"|\breq\.(body|query|params|cookies|headers)\b|\bsys\.argv\b|\$_(GET|POST|REQUEST|COOKIE)\b|\bprocess\.argv\b"
)
EVAL_CALL = re.compile(r"(?<![\w.])(eval|exec)\s*\(|\bnew\s+Function\s*\(")

SQL_STATEMENT = re.compile(
    r"(?i)\b(select\s+[\w*,\s.()]+\s+from\s+\w|insert\s+into\s+\w|update\s+\w+\s+set\b|delete\s+from\s+\w|drop\s+table\b)"
)
SQL_DYNAMIC = [
    (re.compile(r"""\bf["'].*\{[^}]+\}"""), "an f-string"),
    (re.compile(r"""["']\s*\+\s*[\w(]|[\w)\]]\s*\+\s*["']"""), "string concatenation"),
    (re.compile(r"""["']\s*%\s*[\w(]"""), "%-formatting"),
    (re.compile(r"""["']\s*\.format\s*\("""), "str.format()"),
    (re.compile(r"`[^`]*\$\{[^}]+\}"), "a template literal"),
]

SHELL_TRUE = re.compile(r"\bshell\s*=\s*True\b")
NODE_BARE_EXEC = re.compile(r"(?<![\w.])exec(Sync)?\s*\(")
OS_SHELL = re.compile(r"\bos\.(system|popen)\s*\(|\bchild_process\.exec(Sync)?\s*\(|\bexecSync\s*\(|Runtime\.getRuntime\(\)\.exec\s*\(")

PICKLE_LIKE = re.compile(r"\b(c?[Pp]ickle|dill|marshal|jsonpickle)\.(loads?|decode|Unpickler)\s*\(|\bObjectInputStream\s*\(|\bunserialize\s*\(")
YAML_LOAD = re.compile(r"\byaml\.(load|load_all)\s*\(")
YAML_UNSAFE = re.compile(r"\byaml\.(unsafe_load|full_load)\s*\(|Loader\s*=\s*(yaml\.)?(Unsafe|Full)?Loader\b(?!\w)")
YAML_SAFE = re.compile(r"\bC?SafeLoader\b")

WEAK_HASH = re.compile(
    r"""(?i)\bhashlib\.(md5|sha1)\s*\(|\bhashlib\.new\(\s*["'](md5|sha1)["']|createHash\(\s*["'](md5|sha1)["']"""
    r"""|MessageDigest\.getInstance\(\s*["'](md5|sha-?1)["']|(?<![\w.])(md5|sha1)\s*\("""
)
PASSWORD_CONTEXT = re.compile(r"(?i)pass(word|wd)?|\bpwd\b|credential")

ASSIGNMENT = re.compile(r"^\s*(?:(?:const|let|var|final|String)\s+)?\$?([A-Za-z_]\w*)\s*(?::\s*[\w\[\], |]+)?=(?!=)")
UNSAFE_SINK = re.compile(
    r"\b(open|send_file|send_from_directory|redirect|render_template_string|Markup|os\.path\.join|os\.remove|os\.unlink"
    r"|shutil\.\w+|requests\.(get|post|put|delete)|urlopen|__import__|import_module|getattr|setattr|fs\.readFile\w*|res\.redirect)\s*\("
)
VALIDATION = re.compile(
    r"\b(isinstance|validate\w*|fullmatch|match|secure_filename|escape|sanitize\w*|clean\w*|isdigit|isalnum|isnumeric|normpath|abspath|realpath|basename)\s*\("
    r"|\bnot\s+in\b|\bin\s+\w*(ALLOWED|allowed|VALID|valid|WHITELIST|whitelist|ALLOW|allow)\w*|\bBaseModel\b|\bschema\b"
)

TLS_OFF = re.compile(r"\bverify\s*=\s*False\b|rejectUnauthorized\s*:\s*false|CERT_NONE\b")
DEBUG_ON = re.compile(r"\.run\([^)]*\bdebug\s*=\s*True|^\s*DEBUG\s*=\s*True\b")


def _finding(rule_id, category, severity, line_no, line, description, recommendation):
    return {
        "rule_id": rule_id,
        "category": category,
        "severity": severity,
        "line": line_no,
        "code": line.strip()[:160],
        "description": description,
        "recommendation": recommendation,
    }


def _is_comment(line):
    return bool(COMMENT_LINE.match(line))


def _detect_language(code):
    checks = [
        ("php", r"<\?php|\$_(GET|POST)"),
        ("java", r"\bpublic\s+(static\s+)?(class|void)\b|System\.out\."),
        ("javascript", r"\b(const|let)\s+\w+\s*=|=>|require\(|console\.log|\bfunction\s+\w+\s*\("),
        ("python", r"^\s*(def|import|from|class)\s|print\(|:\s*$"),
    ]
    for name, pattern in checks:
        if re.search(pattern, code, re.MULTILINE):
            return name
    return "unknown"


def _check_secrets(n, line):
    out = []
    for pattern, label in KEY_PATTERNS:
        if pattern.search(line):
            out.append(_finding("CS001", "Hardcoded secret", "high", n, line,
                                f"Looks like a hardcoded {label}. Anyone who can read the code or repo history can use it.",
                                "Move it to an environment variable or secrets manager (e.g. os.environ['API_KEY']) and rotate the exposed value."))
            return out
    m = SECRET_ASSIGN.search(line)
    if m and not PLACEHOLDER.match(m.group(2)):
        out.append(_finding("CS001", "Hardcoded secret", "high", n, line,
                            f"A '{m.group(1).lower()}' value is written directly in the source code.",
                            "Load it from an environment variable or secrets manager and rotate the exposed value."))
    return out


def _tainted_names(lines):
    names = set()
    for line in lines:
        m = ASSIGNMENT.match(line)
        if m and TAINT_SOURCE.search(line):
            names.add(m.group(1))
    return names


def _uses_taint(line, tainted_names):
    return bool(TAINT_SOURCE.search(line)) or any(re.search(rf"\b{re.escape(v)}\b", line) for v in tainted_names)


def _check_eval(n, line, ctx):
    m = EVAL_CALL.search(line)
    if not m or (m.group(1) == "exec" and ctx["node_exec"]):
        return []
    tainted = _uses_taint(line, ctx["tainted"])
    return [_finding("CS002", "Dynamic code execution", "critical" if tainted else "high", n, line,
                     "eval()/exec() runs a string as code. If any part of that string comes from a user, they can run any command on your server."
                     + (" Here it is fed user input directly." if tainted else ""),
                     "Remove eval/exec. Use ast.literal_eval for literals, json.loads for data, or an explicit dispatch dict for commands.")]


def _check_sql(n, line):
    if not SQL_STATEMENT.search(line):
        return []
    for pattern, how in SQL_DYNAMIC:
        if pattern.search(line):
            return [_finding("CS003", "SQL injection", "critical", n, line,
                             f"The SQL query is built with {how}, so a crafted value can change the query itself (read, alter or delete data).",
                             "Use parameterized queries, e.g. cursor.execute(\"SELECT * FROM users WHERE id = %s\", (user_id,)), or an ORM.")]
    return []


def _check_shell(n, line, ctx):
    severity = "critical" if _uses_taint(line, ctx["tainted"]) else "high"
    if ctx["node_exec"] and NODE_BARE_EXEC.search(line):
        return [_finding("CS004", "Command injection", severity, n, line,
                         "child_process exec() runs the string through a shell, so characters like ; | && in any variable part can run extra commands.",
                         "Use execFile/spawn with an argument array, e.g. execFile(\"ping\", [\"-c\", \"1\", host]), and validate the input.")]
    if SHELL_TRUE.search(line):
        return [_finding("CS004", "Command injection", severity, n, line,
                         "shell=True passes the command through the system shell, so characters like ; | && in any variable part can run extra commands.",
                         "Pass the command as a list with shell=False, e.g. subprocess.run([\"ls\", path], check=True), and validate arguments.")]
    if OS_SHELL.search(line):
        return [_finding("CS004", "Command injection", severity, n, line,
                         "This call runs a command through the system shell; any variable part can be abused to run extra commands.",
                         "Use subprocess.run([...], shell=False) (or execFile in Node) with an argument list, and validate inputs.")]
    return []


def _check_deserialization(n, line, lines):
    if PICKLE_LIKE.search(line):
        return [_finding("CS005", "Insecure deserialization", "high", n, line,
                         "Loading pickle/marshal-style data can execute arbitrary code if the data comes from an untrusted source.",
                         "Use a data-only format like JSON for untrusted input; only unpickle data you created and signed yourself.")]
    if YAML_UNSAFE.search(line):
        return [_finding("CS005", "Insecure deserialization", "high", n, line,
                         "This YAML loader can build arbitrary Python objects from the input.",
                         "Use yaml.safe_load(data) or yaml.load(data, Loader=yaml.SafeLoader).")]
    if YAML_LOAD.search(line):
        window = " ".join(lines[n - 1:n + 2])
        if not YAML_SAFE.search(window):
            return [_finding("CS005", "Insecure deserialization", "high", n, line,
                             "yaml.load without SafeLoader can create arbitrary Python objects from the input (code execution risk).",
                             "Use yaml.safe_load(data) or yaml.load(data, Loader=yaml.SafeLoader).")]
    return []


def _check_weak_hash(n, line, lines):
    if not WEAK_HASH.search(line):
        return []
    context = " ".join(lines[max(0, n - 4):n + 3])
    if PASSWORD_CONTEXT.search(context):
        return [_finding("CS006", "Weak password hashing", "high", n, line,
                         "MD5/SHA-1 are fast and broken; hashed passwords can be cracked in bulk within hours.",
                         "Use a slow password hash: bcrypt, argon2 (argon2-cffi) or hashlib.pbkdf2_hmac with a random salt.")]
    return [_finding("CS006", "Weak hashing algorithm", "low", n, line,
                     "MD5/SHA-1 are cryptographically broken. Fine for non-security checksums, unsafe for passwords, signatures or tokens.",
                     "Use hashlib.sha256 for integrity checks, and bcrypt/argon2 for passwords.")]


def _check_misc(n, line):
    out = []
    if TLS_OFF.search(line):
        out.append(_finding("CS008", "TLS verification disabled", "medium", n, line,
                            "Certificate checks are turned off, so an attacker on the network can intercept or modify traffic.",
                            "Remove verify=False (or rejectUnauthorized: false); point to a CA bundle if you use a private certificate."))
    if DEBUG_ON.search(line):
        out.append(_finding("CS009", "Debug mode enabled", "medium", n, line,
                            "Debug mode can expose stack traces and an interactive console that allows code execution.",
                            "Disable debug in production; read it from config, e.g. debug=os.environ.get('FLASK_DEBUG') == '1'."))
    return out


def _check_input_validation(lines):
    findings = []
    tainted = {}
    for n, line in enumerate(lines, start=1):
        if _is_comment(line):
            continue
        if TAINT_SOURCE.search(line):
            m = ASSIGNMENT.match(line)
            if m:
                tainted[m.group(1)] = {"line": n, "validated": bool(VALIDATION.search(line)), "reported": False}
            elif UNSAFE_SINK.search(line) and not VALIDATION.search(line):
                findings.append(_finding("CS007", "Missing input validation", "medium", n, line,
                                         "User-controlled input goes straight into a sensitive operation without any checks.",
                                         "Validate first: check type, length and format, and use an allow-list (e.g. secure_filename for file paths)."))
                continue
        for name, state in tainted.items():
            if state["line"] == n or state["reported"] or not re.search(rf"\b{re.escape(name)}\b", line):
                continue
            if VALIDATION.search(line):
                state["validated"] = True
            elif not state["validated"] and UNSAFE_SINK.search(line):
                sink = UNSAFE_SINK.search(line).group(1)
                state["reported"] = True
                findings.append(_finding("CS007", "Missing input validation", "medium", n, line,
                                         f"'{name}' comes from user input (line {state['line']}) and reaches {sink}() without validation (e.g. path traversal or open redirect).",
                                         "Validate before use: check type, length and format, and prefer an allow-list of accepted values."))
    return findings


def scan_vulnerabilities(code: str, language: str = "auto") -> dict:
    """Statically scan a code snippet for common security vulnerabilities.

    Call this for any code that handles secrets or credentials, user input, database queries,
    shell commands, eval/exec, deserialization (pickle, yaml), hashing, file paths or network requests.

    Args:
        code: The full source code snippet to scan, exactly as the user provided it.
        language: Optional language hint such as "python", "javascript", "java" or "php". Use "auto" if unknown.

    Returns:
        A dict with status, language, finding_count, highest_severity and findings. Each finding has
        rule_id, category, severity (low/medium/high/critical), line, code, description and recommendation.
    """
    try:
        if not isinstance(code, str):
            return {"status": "error", "error": "code must be a string", "findings": [], "finding_count": 0}
        if len(code) > MAX_CODE_CHARS:
            return {"status": "error", "error": f"snippet too large (max {MAX_CODE_CHARS} characters)", "findings": [], "finding_count": 0}
        lang = (language or "auto").strip().lower()
        if lang in ("", "auto"):
            lang = _detect_language(code)
        if not code.strip():
            return {"status": "ok", "language": lang, "lines_scanned": 0, "finding_count": 0,
                    "highest_severity": "none", "findings": [], "note": "Empty snippet; nothing to scan."}

        lines = code.splitlines()
        ctx = {"tainted": _tainted_names(lines), "node_exec": "child_process" in code}
        findings = []
        for n, line in enumerate(lines, start=1):
            if not line.strip() or _is_comment(line):
                continue
            findings += _check_secrets(n, line)
            findings += _check_eval(n, line, ctx)
            findings += _check_sql(n, line)
            findings += _check_shell(n, line, ctx)
            findings += _check_deserialization(n, line, lines)
            findings += _check_weak_hash(n, line, lines)
            findings += _check_misc(n, line)
        findings += _check_input_validation(lines)

        unique = {(f["rule_id"], f["line"]): f for f in findings}
        findings = sorted(unique.values(), key=lambda f: (-SEVERITY_RANK[f["severity"]], f["line"]))
        highest = findings[0]["severity"] if findings else "none"
        return {"status": "ok", "language": lang, "lines_scanned": len(lines), "finding_count": len(findings),
                "highest_severity": highest, "findings": findings}
    except Exception as exc:
        return {"status": "error", "error": f"scanner failed: {type(exc).__name__}: {exc}", "findings": [], "finding_count": 0}
